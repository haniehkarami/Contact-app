const inputs = [
  { type: "text", name: "name", placeholder: "Name" },
  { type: "text", name: "lastName", placeholder: "Last Name" },
  { type: "text", name: "email", placeholder: "Email" },
  { type: "number", name: "phone", placeholder: "Phone" },
];
export default inputs;
