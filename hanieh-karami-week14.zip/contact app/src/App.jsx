import { useState } from "react";
import Header from "./component/Header";
import Contact from "./component/Contact";
function App() {
  return (
    <>
      <Header />
      <Contact />
    </>
  );
}

export default App;
