import { useState, useEffect } from "react";

import ContactsList from "./ContactsList";
import inputs from "../constants/inputs";
import { v4 } from "uuid";

import styles from "./Contacts.module.css";
import ConfirmationModal from "./ConfirmationModal";

function Contacts() {
  const [contacts, setContacts] = useState([]);
  const [alert, setAlert] = useState("");
  const [contact, setContact] = useState({
    id: "",
    name: "",
    lastName: "",
    email: "",
    phone: "",
  });
  const [editingId, setEditingId] = useState("");
  const [selectedContacts, setSelectedContacts] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [success, setSuccess] = useState("");
  const [modal, setModal] = useState({
    isOpen: false,
    message: "",
    onConfirm: () => {},
  });
  useEffect(() => {
    if (success) {
      const timer = setTimeout(() => setSuccess(""), 3000);
      return () => clearTimeout(timer);
    }
  }, [success]);

  const changeHandeler = (event) => {
    const { name, value } = event.target;
    setContact((prev) => ({ ...prev, [name]: value }));
    if (alert) setAlert("");
  };

  const validateInputs = () => {
    if (!contact.name) return "Name is required!";
    if (!contact.lastName) return "Last name is required!";
    if (!contact.email) return "Email is required!";
    if (!contact.phone) return "Phone is required!";

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(contact.email)) {
      return "Please enter a valid email (e.g., user@example.com)";
    }

    if (!/^\d{8,}$/.test(contact.phone.replace(/\D/g, ""))) {
      return "Phone must contain at least 8 digits";
    }

    return null;
  };

  const addHandler = () => {
    const errorMessage = validateInputs();
    if (errorMessage) {
      setAlert(errorMessage);
      return;
    }

    setAlert("");
    const newContact = { ...contact, id: v4() };
    setContacts((prev) => [...prev, newContact]);
    setContact({ id: "", name: "", lastName: "", email: "", phone: "" });
  };

  const updateHandler = () => {
    const errorMessage = validateInputs();
    if (errorMessage) {
      setAlert(errorMessage);
      return;
    }
    setAlert("");
    setContacts((prev) =>
      prev.map((item) =>
        item.id === editingId ? { ...contact, id: editingId } : item
      )
    );
    setEditingId("");
    setContact({ id: "", name: "", lastName: "", email: "", phone: "" });
    setAlert("");
  };

  const deleteHandler = (id, name) => {
    showModal(`Are you sure you want to delete ${name}?`, () => {
      setContacts((prev) => prev.filter((contact) => contact.id !== id));
      setSuccess(`${name} deleted successfully`);
    });
  };

  const editHandler = (id) => {
    const contactToEdit = contacts.find((contact) => contact.id === id);
    setContact(contactToEdit);
    setEditingId(id);
  };

  const cancelEdit = () => {
    setEditingId("");
    setContact({ id: "", name: "", lastName: "", email: "", phone: "" });
    setAlert("");
  };

  const toggleSelectContact = (id) => {
    setSelectedContacts((prev) =>
      prev.includes(id)
        ? prev.filter((contactId) => contactId !== id)
        : [...prev, id]
    );
  };

  const deleteSelected = () => {
    if (!selectedContacts.length) return;

    showModal(
      `Are you sure you want to delete ${selectedContacts.length} contact(s)?`,
      () => {
        setContacts((prev) =>
          prev.filter((c) => !selectedContacts.includes(c.id))
        );
        setSelectedContacts([]);
        setSuccess(
          `${selectedContacts.length} contact(s) deleted successfully!`
        );
      }
    );
  };

  const filteredContacts = contacts.filter((contact) => {
    const term = searchTerm.toLowerCase();
    return (
      contact.name.toLowerCase().includes(term) ||
      contact.lastName.toLowerCase().includes(term) ||
      contact.email.toLowerCase().includes(term) ||
      contact.phone.includes(searchTerm)
    );
  });

  const showModal = (message, onConfirm) => {
    setModal({
      isOpen: true,
      message,
      onConfirm: () => {
        onConfirm();
        closeModal();
      },
    });
  };

  const closeModal = () => {
    setModal({ ...modal, isOpen: false });
  };

  return (
    <div className={styles.container}>
      <div className={styles.searchContainer}>
        <input
          type="text"
          placeholder="Search by name, last name, email or phone..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className={styles.searchInput}
        />
      </div>
      {editingId && (
        <div className={styles.editAlert}>
          <p>You are editing a contact</p>
          <button onClick={cancelEdit}>✖️</button>
        </div>
      )}
      <div className={styles.form}>
        {inputs.map((input, index) => (
          <input
            key={index}
            type={input.type}
            placeholder={input.placeholder}
            name={input.name}
            value={contact[input.name]}
            onChange={changeHandeler}
          />
        ))}

        <button onClick={editingId ? updateHandler : addHandler}>
          {editingId ? "Update Contact" : "Add Contact"}
        </button>
      </div>

      {alert && (
        <div className={styles.errorAlert}>
          <p>{alert}</p>
        </div>
      )}

      {success && (
        <div className={styles.alert}>
          <p>{success}</p>
        </div>
      )}

      <ContactsList
        contacts={searchTerm ? filteredContacts : contacts}
        deleteHandler={(id) => {
          const contact = contacts.find((c) => c.id === id);
          deleteHandler(id, `${contact.name} ${contact.lastName}`);
        }}
        editHandler={editHandler}
        selectedContacts={selectedContacts}
        toggleSelectContact={toggleSelectContact}
      />
      <ConfirmationModal
        isOpen={modal.isOpen}
        message={modal.message}
        onConfirm={modal.onConfirm}
        onCancel={closeModal}
      />
      {selectedContacts.length > 0 && (
        <button
          onClick={deleteSelected}
          className={styles.deleteSelectedButton}
        >
          Delete Selected ({selectedContacts.length})
        </button>
      )}
    </div>
  );
}

export default Contacts;
