import ContactItem from "./ContactItem";
import ConfirmationModal from "./ConfirmationModal";

import styles from "./ContactsList.module.css";

function ContactsList({
  contacts,
  deleteHandler,
  editHandler,
  toggleSelectContact,
  selectedContacts,
  searchTerm,
}) {
  return (
    <div className={styles.container}>
      <h3>Contacts List</h3>
      {/* اگر صفر نبود و وجود داشت مپ بزن و کانتکت ها را نشان بده اگر نه تگ پی را نشان بده */}
      {contacts.length ? (
        <ul className={styles.contacts}>
          {contacts.map((contact) => (
            <ContactItem
              key={contact.id}
              data={contact}
              deleteHandler={deleteHandler}
              editHandler={editHandler}
              selectedContacts={selectedContacts}
              toggleSelectContact={toggleSelectContact}
            />
          ))}
        </ul>
      ) : (
        <p className={styles.message}>No Contact Yet!</p>
      )}
    </div>
  );
}
export default ContactsList;
